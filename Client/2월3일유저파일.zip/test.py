import mysql.connector
import base64

def convertToBinaryData(filename):
    with open(filename, 'rb') as file:
        binaryData = file.read()
    
    return binaryData

# convertToBinaryData("C:\Language\Python\Python\Client\gb.jpg")

def insertBLOB(name, photo, ip, port):
    print("Inserting BLOB into chating_member table")
    try:
        connection = mysql.connector.connect(host='localhost',
                                            database='chat',
                                            user='root',
                                            password='0000')
        cursor = connection.cursor()
        sql_insert_blob_query = """ INSERT INTO chating_member
                            (name, photo, ip, port) VALUES (%s,%s,%s,%s)"""
        empPicture = convertToBinaryData(photo)
        print(empPicture)
        # file = convertToBinaryData(empPicture)

        insert_blob_tuple = (name, empPicture, ip, port)
        result = cursor.execute(sql_insert_blob_query, insert_blob_tuple)
        connection.commit()
        print("Image and file inserted successfully as a BLOB into chating_member table", result)
    
    except mysql.connector.Error as error:
        print("Failed inserting BLOB data into MySQL table {}".format(error))
    
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

insertBLOB("Yuiyong", "C:\Language\Python\Python\Client\one2.png", "d", "d")
# insertBLOB(2, "Park", "C:\Language\Python\Python\Client\gb.jpg", "C:\Language\Python\Python\Client\park_bioData.txt")